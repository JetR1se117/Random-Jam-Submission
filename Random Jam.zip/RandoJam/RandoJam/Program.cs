﻿using System;
using System.Collections.Generic;
namespace RandoJam
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("START");
            QuestMgr qt = new QuestMgr();

            string quitStr = " ";
            while (quitStr != "q")
            {
                //qt.Opener();
                //qt.startQuest();
                qt.shellQuest();
                Console.WriteLine("If you would like to quit, type 'q'. Else, press enter to continue");
                quitStr = Console.ReadLine();
                if (qt.happiness <= 0 || qt.money <= 0)
                {
                    quitStr = "q";
                }
            }
        }
    }

    class QuestMgr
    {
        qData qD = new qData();

        public int happiness;
        public int happinessThreshold;
        public int money;


        public int dayCounter;

        public string[] questStrings;
        public string[] goStrings;
        public string[] getStrings;
        public string[] killStrings;
        public string[] motivationStrings;
        public string[] descriptorStrings;
        public string[] getDescriptorStrings;
        public string[] personStrings;
        int questType;

        Player player;

        Random r = new Random();
        int randomSeed;
        public QuestMgr() 
        {

            questStrings = new string[] { "go", "get", "kill" };

            //  QUEST GEN - <TYPE>
            goStrings = new string[] { " castle", " village", " cave" };
            getStrings = new string[] { " sword", " antidote", " gift" };
            killStrings = new string[] { " monster", " elves", " dragon", " ghost" };
            //  QUEST GEN - </TYPE>

            motivationStrings = new string[] { " avenge", " save", " cure opioid addiction" };
            descriptorStrings = new string[] { " ancient", " evil", " holy", " glistening" };
            getDescriptorStrings = new string[] { " dull", " cursed", " beryll", " sharp", " glowing", " mystical" };
            personStrings = new string[] { " mother", " father", " brother", " sister", " friend", " companion", " wife", " husband" };

            money = 20;
            happiness = 20; // happiness + money - build state change during sentence generation, then give player choice of a/b which will affect the states

            dayCounter = 10;
            happinessThreshold = 100;

            Console.WriteLine("A terrible disaster will hit in " + dayCounter + " days. \nComplete quests to build up your \nhappiness to over " + happinessThreshold + " in order to survive. \nBut be careful; if you run out of money or happiness you will die prematurely.\n\n");

            // start of new stuff. everything prior in the function is liable to being scrapped or reworked.
            player = new Player();
            randomSeed = 0;
        }

        public void Opener()
        {
            string testString = " ";
            Random yes = new Random();
            questType = yes.Next(0, 3);
            int pleaseNum = yes.Next(0, 5);
            if (pleaseNum == 1)
                testString = testString + "please ";


            // 
            int moneyChange = 0;
            int happChange = 0;


            testString = testString + questStrings[questType];
            int goNum = yes.Next(0, goStrings.Length);
            int getNum = yes.Next(0, getStrings.Length);
            int killNum = yes.Next(0, killStrings.Length);
            int motNum = yes.Next(0, motivationStrings.Length);
            int descNum = yes.Next(0, descriptorStrings.Length);
            int getDescNum = yes.Next(0, getDescriptorStrings.Length);
            int personNum = yes.Next(0, personStrings.Length);




            int formatNum = yes.Next(0, 2); // this is to have different orders of quest give. give location first, or motivation?

            if (formatNum == 1)
            {
                switch (questType)
                {
                    case 0:


                        testString = testString + " to the" + descriptorStrings[descNum] + goStrings[goNum] + " to";
                        /*
                        if (motivationStrings[motNum] != " avenge")
                        {
                            Console.Write(motivationStrings[motNum]);
                            moneyChange = moneyChange + 10;
                        }
                        */

                        testString = testString + motivationStrings[motNum];
                        if (motivationStrings[motNum] == " save")
                        {
                            happChange = happChange + 10;
                        }
                        moneyChange = moneyChange + 10;
                        happChange = happChange + 10;
                        break;

                    case 1:
                        testString = testString + " the" + getDescriptorStrings[getDescNum] + getStrings[getNum] + " to" + motivationStrings[motNum];
                        moneyChange = moneyChange - 10;
                        happChange = happChange + 10;
                        break;

                    case 2:

                        testString = testString + " the" + descriptorStrings[descNum] + killStrings[killNum] + " to" + motivationStrings[motNum];
                        if (motivationStrings[motNum] == " avenge")
                        {
                            happChange = happChange + 10;
                            testString = testString + personStrings[personNum];
                        }
                        else if (motivationStrings[motNum] == " save")
                        {
                            happChange = happChange + 20;
                            testString = testString + personStrings[personNum];
                        }
                        moneyChange = moneyChange + 10;
                        happChange = happChange - 10;
                        break;
                }
                if (motivationStrings[motNum] == " save")
                {
                    testString = testString + personStrings[personNum];
                    happChange = happChange + 10;
                }
            }
            else
            {
                switch (questType)
                {
                    case 0:
                        moneyChange = moneyChange - 10;
                        testString = testString + " to the" + descriptorStrings[descNum] + goStrings[goNum] + " to" + motivationStrings[motNum];
                        if (motivationStrings[motNum] == " save") {
                            testString = testString + personStrings[personNum];
                            happChange = happChange + 10;
                        }
                        break;

                    case 1:
                        if (motivationStrings[motNum] == " save")
                        {
                            happChange = happChange + 20;
                            testString = testString + personStrings[personNum];
                        }
                        else if (motivationStrings[motNum] != " avenge")
                        {
                            testString = testString + " to" + motivationStrings[motNum];
                            happChange = happChange + 10;
                        }
                        else
                        {
                            motNum++;
                            testString = testString + " to" + motivationStrings[motNum];
                        }
                        testString = testString + " the" + getDescriptorStrings[getDescNum] + getStrings[getNum];
                        moneyChange = moneyChange - 10;
                        //happChange = happChange + 10;
                        break;

                    case 2:
                        testString = testString + " to" + motivationStrings[motNum];   //+ " the" + descriptorStrings[descNum] + killStrings[killNum]);
                        if (motivationStrings[motNum] == " save")
                        {
                            testString = testString + personStrings[personNum];
                            happChange = happChange + 20;
                        }
                        if (motivationStrings[motNum] == " avenge")
                        {
                            testString = testString + personStrings[personNum];
                            happChange = happChange + 10;
                        }
                        testString = testString + " the" + descriptorStrings[descNum] + killStrings[killNum];
                        happChange = happChange - 10;
                        moneyChange = moneyChange + 10;
                        break;

                }
            }
            Console.WriteLine(testString);

            Console.WriteLine("\nCurrent money: " + money + " | Current happiness: " + happiness + "\n\nIf you take the quest: \nmoney change: " + moneyChange + " | happiness change: " + happChange);
            Console.WriteLine("If you do not take the quest:\nmoney change: " + -moneyChange + " | happiness change: " + -happChange);
            string yesNoStr = " ";
            while (yesNoStr != "y" && yesNoStr != "n")
            {
                Console.Write("y/n : ");
                yesNoStr = Console.ReadLine();
            }
            if (yesNoStr == "y")
            {
                money = money + moneyChange;
                happiness = happiness + happChange;
            }
            else
            {
                money = money - moneyChange;
                happiness = happiness - happChange;
            }
            Console.WriteLine("Current money: " + money + " | Current Happiness: " + happiness);
            if (happiness <= 0)
            {
                Console.WriteLine("Your happiness is gone. You lose the will to live and die.");
            }
            if (money <= 0)
            {
                Console.WriteLine("You have no money. You starve and die.");
            }
            if (dayCounter == 0)
            {
                Console.Write("The disaster has hit! ");
                if (happiness > happinessThreshold)
                {
                    Console.Write("You gained enough happiness to endure the anguish of the disaster, and survived.");
                }
                else
                {
                    Console.Write("You did not gain enough happiness to endure the anguish of the disaster, and perished.");
                    happiness = happiness - 1000;
                }
            }
            else
            {
                dayCounter--;
            }
        } // Old Function. For old version :D
        public void startQuest()   // Where quest starts (obviously!) // new quest gen version
        {
            randomSeed = r.Next(111111, 999999);
            Quest quest = new Quest(randomSeed);
            bool exitBool = false;
            while((quest.taskCount <6) || (exitBool))
            {
                // this needs to have the bulk of sentence gen. Will reference qData and most objects v frequently.

                string testString = " ";
                questType = randomSeed % 3;
                int pleaseNum = randomSeed % 5;
                if (pleaseNum == 1)
                    testString = testString + "please ";

                int moneyChange = 0;
                int happChange = 0;


                testString = testString + questStrings[questType];
                int goNum = randomSeed % goStrings.Length; // Locations
                int getNum = randomSeed % qD.items.Count; // Items
                int killNum = randomSeed % qD.creatures.Count; // Creatures
                int motNum = randomSeed % motivationStrings.Length; // Intent
                int descNum = randomSeed % descriptorStrings.Length; // descriptor
                int getDescNum = randomSeed % getDescriptorStrings.Length; //descriptor
                int personNum = randomSeed % qD.names.Count; // person

                int formatNum = randomSeed % 2; // this is to have different orders of quest give. give location first, or motivation?

                if (formatNum == 1)
                {
                    switch (questType)
                    {
                        case 0:
                            testString = testString + " to the" + descriptorStrings[descNum] + goStrings[goNum] + " to";
                            /*
                            if (motivationStrings[motNum] != " avenge")
                            {
                                Console.Write(motivationStrings[motNum]);
                                moneyChange = moneyChange + 10;
                            }
                            */

                            testString = testString + motivationStrings[motNum];
                            if (motivationStrings[motNum] == " save")
                            {
                                happChange = happChange + 10;
                            }
                            moneyChange = moneyChange + 10;
                            happChange = happChange + 10;
                            break;

                        case 1:
                            testString = testString + " the" + getDescriptorStrings[getDescNum] + getStrings[getNum] + " to" + motivationStrings[motNum];
                            moneyChange = moneyChange - 10;
                            happChange = happChange + 10;
                            break;

                        case 2:

                            testString = testString + " the" + descriptorStrings[descNum] + killStrings[killNum] + " to" + motivationStrings[motNum];
                            if (motivationStrings[motNum] == " avenge")
                            {
                                happChange = happChange + 10;
                                testString = testString + personStrings[personNum];
                            }
                            else if (motivationStrings[motNum] == " save")
                            {
                                happChange = happChange + 20;
                                testString = testString + personStrings[personNum];
                            }
                            moneyChange = moneyChange + 10;
                            happChange = happChange - 10;
                            break;
                    }
                    if (motivationStrings[motNum] == " save")
                    {
                        testString = testString + personStrings[personNum];
                        happChange = happChange + 10;
                    }
                }
                else
                {
                    switch (questType)
                    {
                        case 0:
                            moneyChange = moneyChange - 10;
                            testString = testString + " to the" + descriptorStrings[descNum] + goStrings[goNum] + " to" + motivationStrings[motNum];
                            if (motivationStrings[motNum] == " save")
                            {
                                testString = testString + personStrings[personNum];
                                happChange = happChange + 10;
                            }
                            break;


                        case 1:

                            if (motivationStrings[motNum] == " save")
                            {
                                happChange = happChange + 20;
                                testString = testString + personStrings[personNum];
                            }
                            else if (motivationStrings[motNum] != " avenge")
                            {
                                testString = testString + " to" + motivationStrings[motNum];
                                happChange = happChange + 10;
                            }
                            else
                            {
                                motNum++;
                                testString = testString + " to" + motivationStrings[motNum];
                            }
                            testString = testString + " the" + getDescriptorStrings[getDescNum] + getStrings[getNum];
                            moneyChange = moneyChange - 10;
                            //happChange = happChange + 10;
                            break;

                        case 2:

                            testString = testString + " to" + motivationStrings[motNum];   //+ " the" + descriptorStrings[descNum] + killStrings[killNum]);
                            if (motivationStrings[motNum] == " save")
                            {
                                testString = testString + personStrings[personNum];
                                happChange = happChange + 20;
                            }
                            if (motivationStrings[motNum] == " avenge")
                            {
                                testString = testString + personStrings[personNum];
                                happChange = happChange + 10;
                            }
                            testString = testString + " the" + descriptorStrings[descNum] + killStrings[killNum];
                            happChange = happChange - 10;
                            moneyChange = moneyChange + 10;
                            break;

                    }
                }

                Console.WriteLine(testString);

                Console.WriteLine("\nCurrent money: " + money + " | Current happiness: " + happiness + "\n\nIf you take the quest: \nmoney change: " + moneyChange + " | happiness change: " + happChange);
                Console.WriteLine("If you do not take the quest:\nmoney change: " + -moneyChange + " | happiness change: " + -happChange);
                string yesNoStr = " ";
                while (yesNoStr != "y" && yesNoStr != "n")
                {
                    Console.Write("y/n : ");
                    yesNoStr = Console.ReadLine();
                }
                if (yesNoStr == "y")
                {
                    money = money + moneyChange;
                    happiness = happiness + happChange;
                }
                else
                {
                    money = money - moneyChange;
                    happiness = happiness - happChange;
                }
                Console.WriteLine("Current money: " + money + " | Current Happiness: " + happiness);
                if (happiness <= 0)
                {
                    Console.WriteLine("Your happiness is gone. You lose the will to live and die.");
                }
                if (money <= 0)
                {
                    Console.WriteLine("You have no money. You starve and die.");
                }
                if (dayCounter == 0)
                {
                    Console.Write("The disaster has hit! ");
                    if (happiness > happinessThreshold)
                    {
                        Console.Write("You gained enough happiness to endure the anguish of the disaster, and survived.");
                    }
                    else
                    {
                        Console.Write("You did not gain enough happiness to endure the anguish of the disaster, and perished.");
                        happiness = happiness - 1000;
                    }
                }
                else
                {
                    dayCounter--;
                }

            }
        }


        public void shellQuest()
        {
            randomSeed = r.Next(111111, 999999);

            Console.WriteLine("in QuestMgr.shellQuest():: randomSeed = " + randomSeed);
            Quest quest = new Quest(randomSeed);
            Task task = quest.taskGen(randomSeed%3, true);
            quest.tasks.Add(task);
            string input = "";
            bool exitLoop = false;
            int breakNum = 1000;
            for (int i = 0; i < quest.taskCount; i++)
            {
                
                Console.WriteLine("taskCount = " + quest.taskCount);
                Console.WriteLine("int i = " + i);

                Console.WriteLine(quest.tasks[i].Write());
                quest.QuestLog = quest.QuestLog + "\n";
                quest.QuestLog = quest.QuestLog + quest.tasks[i].Write();
                Console.WriteLine("DEBUG:: moneyVal = " + quest.tasks[i].moneyChange + " | happVal = " + quest.tasks[i].happinessChange);

                input = "";
                int failCount = 0;
                while ((!exitLoop) && input != "q" && input != "~ERROR!")
                {
                    Console.WriteLine("Enter y/n to accept or decline task");
                    Console.Write(" >");
                    input = Console.ReadLine();
                    if (input == "y")
                    {
                        Console.WriteLine("DEBUG:: accepted Task");
                        quest.QuestLog = quest.QuestLog + "\nAccepted Task";
                        player.money = player.money + task.moneyChange;
                        player.happiness = player.happiness + task.happinessChange;
                        exitLoop = true;
                    }
                    if (input == "n")
                    {
                        Console.WriteLine("DEBUG:: rejected Task");
                        quest.QuestLog = quest.QuestLog + "\nRejected Task";
                        exitLoop=true;
                    }

                    failCount++;            // just incase the program dies on me because its a git
                    if (failCount > 20)
                    {
                        
                        input = "~ERROR!";
                        Console.WriteLine("ERROR:: Timed out, output ERROR\n");
                        Console.WriteLine("input = " + input);
                        exitLoop=true;
                    }

                }
                if (input == "~ERROR!") // Enter this if for some reason the program breaks in here and wont leave this input box
                {
                    Console.WriteLine("in QuestMgr.shellQuest()::" +
                        "\n   task.happinessChange = " + task.happinessChange + 
                        "\n   ");
                }
                int randomSeedx = randomSeed * (i + 2);
                task = quest.taskGen(randomSeedx % 3, randomSeedx);
                quest.tasks.Add(task);
                if(i > breakNum)
                {
                    break;
                }
            }
        }
    }



    // quest overall

    class Quest
    {
        /* needed items:
        
        Tasks, Characters, Text Log (List)
        quest giver (string)
        money cost/gain/ + total, happiness cost/gain + total (int)



        NOTES:
        other characters (Generate at each task)
         
         */

        public int getTotalMoneyCost()  //returns moneyCostTotal for whole quest
        {
            return moneyCostTotal;
        }
        public int getTotalHappinessCost()  //returns happinessCostTotal for whole quest
        {
            return happinessCostTotal;
        }

        public string QuestLog; // This should store all text and player responses as a log.
                                      // Should be retrievable at all times the program is active until closed
        private int randomSeed;

        public int taskCount;

        public List<Task> tasks;

        public Character questGiver;

        public List<Character> relevantCharacters = new List<Character>(); // stores created characters in tasks for use later in quest

        int moneyCostTotal;          // tracks total money cost of quest

        int happinessCostTotal;          // tracks total happiness cost of quest

        public Quest(int randomSeed)
        {
            questGiver = new Character(randomSeed, true);

            taskCount = 0;


            QuestLog = ""; // stores the speech output in one list of strings. Can be used as history
            tasks = new List<Task>(); // stores all tasks. Can be used later as history.

            int taskNum = randomSeed % 3 + 1;
            Console.WriteLine(taskNum);
            this.randomSeed = randomSeed;
        }
        public Task taskGen(int taskNum, int randomSeed)
        {

            Task task = new Task();
            switch (taskNum)
            {
                case 1:
                    task = new Go();
                    break;
                case 2:
                    task = new Get(randomSeed);
                    break;
                case 3:
                    task = new Kill(randomSeed);
                    break;
                default:
                    Console.WriteLine("Error:: DEBUG LOG: taskNum in Task.taskGen() during task 2 or over = " + taskNum);
                    break;
            }
            return task;
        }
        public Task taskGen(int taskNum, bool check) // for first task in a quest
        {
            Task task = new Task();
            Console.WriteLine("In Task.taskGen():: taskNum = " + taskNum);
            switch (taskNum)
            {
                case 1:
                    task = new Go();
                    Console.WriteLine("In Task.taskGen():: Task = Go");
                    break;
                case 2:
                    task = new Get(randomSeed);
                    Console.WriteLine("In Task.taskGen():: Task = Get");
                    break;
                case 3:
                    task = new Kill(randomSeed);
                    Console.WriteLine("In Task.taskGen():: Task = Kill");
                    break;
                default:
                    Console.WriteLine("Error:: DEBUG LOG: taskNum in Task.taskGen() first task in quest = " + taskNum);
                    break;
            }
            task.first = true;
            taskCount++;
            return task;
        }

        public void taskPlay(int taskNum, int incrementer)
        {
            bool exitLoop = false;
            string input = "";
            while ((!exitLoop) ||input!="q") {
                Console.WriteLine(tasks[incrementer].Write());
                QuestLog = QuestLog + "\n";
                QuestLog = QuestLog + tasks[incrementer].Write();
                Console.WriteLine("DEBUG:: moneyVal = " + tasks[incrementer].moneyChange + " | happVal = " + tasks[incrementer].happinessChange);
                Console.WriteLine("Enter y/n to accept or decline task");
                Console.Write(" >");
                input = Console.ReadLine();
                if (input == "y")
                {
                    Console.WriteLine("DEBUG:: accepted Task");
                    QuestLog = QuestLog + "\nAccepted Task";
                }
                if (input == "n")
                {
                    Console.WriteLine("DEBUG:: rejected Task");
                    QuestLog = QuestLog + "\nRejected Task";
                }
            }


            /// all below could be put somewhere else - really we just need to get using this now
                Task task = null;
                Console.Write(tasks[incrementer].Write());
                task = taskGen(taskNum, randomSeed * incrementer + 2);
                tasks.Add(task);
        }

    }


    class Task
    {
        qData qD = new qData();
        /* needed Items:

        text Log(string)
        happiness change/money change, Task Type(int)
        task types: get, go, kill(Task)
        Characters (List)
         */
        public bool first;

        public int happinessChange;
        public int moneyChange;
        public string TaskType; // 1:Go; 2:Get; 3:Kill;

        public string TextLog = " ";
        public string Write() { return TextLog; }

        public List<Character> relevantCharacters = new List<Character> ();
    }// parent Task class
    class Go : Task
    {
        string taskLocation;
        string taskDescription;
        public Go()
        {
            first = false;
            TaskType = "Go";
            taskLocation = "placeholder ";
            happinessChange = 0;
            moneyChange = 0;
        }

        public string Write(int randomSeed)
        {
            qData qd = new qData();
            taskLocation = qd.locationsL[randomSeed % qd.locationsL.Count][0];
            moneyChange = moneyChange + Int16.Parse(qd.locationsL[randomSeed % qd.locationsL.Count][1]);
            string taskWriter = "";
            taskWriter = taskWriter + "Go to " + taskLocation; // writes start of task description to string, + location to go.
            // potentially have 3 different branches:
            // 1: No more, task is left at that
            // 2: offer money to player, increase total money reward
            // 3: give motivation reason to go, add happiness modifier.
            //  
            switch ((randomSeed %3) - 1)
            {
                case 1:
                    int cashReward = (randomSeed % 3) * 10;
                    taskWriter = taskWriter + "and you shall be rewarded with " + cashReward + " money.";
                    break;

                case 2:
                    taskWriter = taskWriter + "for " + relevantCharacters[0].motivation + ".";
                    break;

                default:
                    taskWriter = taskWriter + ".";
                    break;
            }
            return taskWriter;
        }

    }// go class : child of Task
    class Get : Task
    {
        qData qd = new qData();
        Item itemToGet;
        public Get(int randomSeed)
        {
            first = false;
            TaskType = "Get";
            itemToGet = qd.objItems[randomSeed%(qd.objItems.Count-1)];
            itemToGet.description = qd.descriptions[randomSeed%qd.descriptions.Count][0];
            happinessChange = Int16.Parse(qd.descriptions[randomSeed%qd.descriptions.Count][1]);
            moneyChange = 0;
        }

        public string Write(int randomSeed)
        {
            itemToGet = qd.objItems[randomSeed%qd.objItems.Count-1]; // gets item for list randomly via randomseed.
            int descNum = randomSeed%qd.descriptions.Count-1;
            itemToGet.description = qd.descriptions[descNum][0];
            itemToGet.happValue = Int16.Parse(qd.descriptions[descNum][1]);

            string taskWriter = "";

            taskWriter = taskWriter + "get "; // writes start of task description to string, + item to get
            // potentially have 3 different branches:
            // 1: No more, task is left at that
            // 2: offer money to player, increase total money reward
            // 3: give motivation reason to go, add happiness modifier.
            //  
            switch ((randomSeed % 3) - 1)
            {
                case 1:
                    int cashReward = (randomSeed % 3) * 10;
                    taskWriter = taskWriter + "and you shall be rewarded with " + cashReward + " money.";
                    break;

                case 2:
                    taskWriter = taskWriter + "for " + relevantCharacters[0].motivation;
                    break;

                default:
                    taskWriter = taskWriter + ".";
                    break;
            }
            return taskWriter;
        }

    }// get class : child of Task
    class Kill : Task
    {
        Creature targetCreature;
        qData qd;
        public Kill(int RandomSeed)
        {
            first = false;
            TaskType = "Kill";
            targetCreature = qd.creatures[RandomSeed%(qd.creatures.Count+1)];
            happinessChange = targetCreature.happinessGainFromKill;
            moneyChange = targetCreature.costToKill;
        }

        public string Write(int randomSeed)
        {
            string taskWriter = "";
            taskWriter = taskWriter + "Kill " + targetCreature.name; // writes start of task description to string, + location to go.
            // potentially have 3 different branches:
            // 1: No more, task is left at that
            // 2: offer money to player, increase total money reward
            // 3: give motivation reason to go, add happiness modifier.
            //  
            switch ((randomSeed % 3) - 1)
            {
                case 1:
                    int cashReward = (randomSeed % 3) * 10;
                    taskWriter = taskWriter + "and you shall be rewarded with " + cashReward + " money.";
                    break;

                case 2:
                    taskWriter = taskWriter + "for " + relevantCharacters[0].motivation;
                    break;

                default:
                    taskWriter = taskWriter + ".";
                    break;
            }

            return taskWriter;
        }

    }// kill class : child of Task





    // data

    class Player
    {
        public int happiness;
        public int money;
        int questsDone;
        public Player()
        {
            happiness = 10;
            money = 10;
            questsDone = 0;
        }
        public void questDone()
        {
            questsDone++;
        }
    }
    class qData
    {
        public List<string> names;
        
        public List<string[]> locationsL;

        public Dictionary<string,int> intentD;

        public List<string> motivations;

        public Dictionary<string, int> descriptionsD;
        public List<string[]> descriptions;

        public List<string> items;
        public List<Item> objItems = new List<Item>();

        public List<Creature> creatures;

        /* Need to do List:
         change the dictionaries into List of objects
        add new object classes (Location, intent, description, motivation?, items?)
         */

        void Names()
        {
            names = new List<string>() { " mother", " father", " brother", " sister", " friend", " companion", " wife", " husband" };
        }
        void Locations()
        {
            // <location name, money change>
            // this should affect the financial cost of completing a task;
            locationsL = new List<string[]> {};

            string[] item = new string[] { " castle", "0" };
            locationsL.Add(item);
            item = new string[] { " village", "0" };
            locationsL.Add(item);
            item = new string[] { " cave", "0" };
            locationsL.Add(item);
            item = new string[] { " city", "0" };
            locationsL.Add(item);
            item = new string[] { " church", "0" };
            locationsL.Add(item);
            item = new string[] { " farm", "0" };
            locationsL.Add(item);
            item = new string[] { " island", "10" };
            locationsL.Add(item);

        }
        void Intent()
        {
            // <intent name, happiness change>
            intentD = new Dictionary<string, int>() { {" avenge", -10 },{" cure" , 20 },{" imitate", -10 },{" break", -10 }, { " rescue", 20}, {" null", 0 } }; // this should affect a tasks aim
        }
        void Motivations()
        {
            motivations = new List<string>() { "political career", "heroism", "amusement", "love", "save", "trick" }; // this should affect overarching quest narrative
        }
        void Descriptions()
        {
            // <description name, happiness change>
            descriptionsD = new Dictionary<string, int>() { { " ancient", 0}, { " evil", -30 }, { " holy", 20 }, { " glistening", 0 }, { " dull", 0 }, { " cursed", -20 }, { " beryll", -10 }, { " sharp", -10 }, { " glowing", 10 }, { " mystical",20 }, { " chaotic", -10 } };
            descriptions = new List<string[]> { };
            string[] description = new string[] { " ", "0" };
            descriptions.Add(description);
            description = new string[] { " ancient", "0" };
            descriptions.Add(description);
            description = new string[] { " evil", "-30" };
            descriptions.Add(description);
            description = new string[] { " holy", "20" };
            descriptions.Add(description);
            description = new string[] { " glistening", "0" };
            descriptions.Add(description);
            description = new string[] { " dull", "0" };
            descriptions.Add(description);
            description = new string[] { " cursed", "-20" };
            descriptions.Add(description);
            description = new string[] { " beryll", "-10" };
            descriptions.Add(description);
            description = new string[] { " sharp", "-10" };
            descriptions.Add(description);
            description = new string[] { " glowing", "10" };
            descriptions.Add(description);
            description = new string[] { " mystical", "20" };
            descriptions.Add(description);
            description = new string[] { " chaotic", "-10" };
            descriptions.Add(description);
        }
        void Items()
        {
            items = new List<string>() { " sword", " antidote", " gift", " shield", "book", "staff", "boots", "gloves"};
            List<int> itemsMoneyValue = new List<int> { 20,30,20,20,10,40,20,10 };

            for(int i = 0; i < items.Count; i++)
            {
                Item item = new Item();
                item.itemValue = itemsMoneyValue[i];
                item.itemName = items[i];
                objItems.Add(item);
            }

        }
        void Creatures()
        {
            List<string> creatureName = new List<string>() { " elf", " dragon", " ghost", " zombie", " dendroid" , "gremlin"};
            List<string> creaturePlural = new List<string>() { " elves", " dragons", " ghosts", " zombies", " dendroids", "gremlins" };
            List<int> creatureMoneyValue = new List<int>() { 20, 60, 20, 10, 30, 10 };      // if creature killed, should get.. as base value
            List<int> creatureHappValue = new List<int>() { -20, 40, 20, 20, 10, 10 };    // if creature killed, should get.. as base value
            creatures = new List<Creature>();
            for (int i = 0; i < creatureName.Count; i++)
            {
                Creature c = new Creature();
                creatures.Add(c);
                creatures[i].name = creatureName[i];
                creatures[i].pluralName = creaturePlural[i];
                creatures[i].costToKill = creatureMoneyValue[i];
                creatures[i].happinessGainFromKill = creatureHappValue[i];
            }
        }

        public qData()
        {




            Names();
            Locations();
            Intent();
            Motivations();
            Descriptions();
            Items();
            Creatures();
        }

    }


    //datatypes
    class Character
    {
        /* needed items:
        
        name, motivation (string)
        age (int)
        relations?(Character)
        */

        qData qD = new qData();

        public string name;
        public string motivation;
        public int age;

        public bool alignment; // Good / bad? true/false

        public bool qGiver;

        List<Character> relations;
        public Character(int randomSeed, bool first) // should only be called on first ini of a quest
        {

            
            bool errored = true;
            while (!errored)
            {
                errored = false;
                try
                {
                    name = qD.names[randomSeed * 29 % qD.names.Count];
                    motivation = qD.motivations[randomSeed * 9 % (qD.names.Count)];
                    qGiver = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("error in Character:Character() exception thrown, regenerating");
                    errored = true;
                }
            }
            
        }
        public Character(int randomSeed) // random seed to determine values
        {
            name = qD.names[randomSeed * 29 % qD.names.Count];
            motivation = qD.motivations[randomSeed * 9 % qD.names.Count];
            qGiver = false;
        }
    }
    class Creature{
        public string name;
        public string pluralName;
        public string trait;
        public int costToKill;
        public int happinessGainFromKill;


        public Creature()
        {
            string name = "placeholder";
            string plural = "placeholders";
            string trait = " dull";
            int moneyValue = -10;
            int happinessValue = -10;
        }

    }
    class Item
    {
        public string itemName;
        public string description;
        public int itemValue;
        public int happValue;
        public Item()
        {
            itemName = "placeholder";
            itemValue = 0;
            description = " dull";
            happValue = 0;
        }
    }
}